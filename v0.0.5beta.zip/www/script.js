// --- Константы ---
const serverNames = ["vpn1.miragvpn.fun", "vpn2.miragvpn.fun", "vpn3.miragvpn.fun"];
const periodMinutes = 1440; // 24 часа
const columnsCount = 48; // 48 столбиков (по 30 минут)
let currentServer = serverNames[0];
let currentData = [];

// --- Canvas ---
const canvas = document.getElementById('stabilityChart');
const tooltip = document.getElementById('chartTooltip');
const ctx = canvas.getContext('2d');

// --- Адаптив под телефон ---
function resizeCanvas() {
  const parentWidth = canvas.parentElement.offsetWidth;
  canvas.width = parentWidth;
  canvas.height = 80;
  drawChart();
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// --- Получение сетевой нагрузки ---
async function fetchNetdataNetworkLoad() {
  const timestamp = Date.now();
  const points = periodMinutes; // 1440 минут за сутки
  const url = `http://178.17.49.232:19999/api/v1/data?chart=system.net&points=${points}&group=average&_=${timestamp}`;
  try {
    const res = await fetch(url);
    const data = await res.json();
    const max = Math.max(...data.data.map(row => row[1]));
    return data.data.map(row => max ? row[1] / max * 100 : 0); // нормируем в %
  } catch (e) {
    console.error('Ошибка API:', e);
    return Array(points).fill(0);
  }
}

// --- Усреднение данных за полчаса ---
function averageDataForColumns(rawData) {
  const groupSize = Math.floor(rawData.length / columnsCount);
  const averaged = [];
  for (let i = 0; i < columnsCount; i++) {
    const group = rawData.slice(i * groupSize, (i + 1) * groupSize);
    const avg = Math.round(group.reduce((sum, val) => sum + val, 0) / group.length);
    averaged.push(avg);
  }
  return averaged;
}

// --- Рисуем график ---
async function drawChart() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Получаем данные если пусто
  if (currentData.length === 0) {
    const rawData = await fetchNetdataNetworkLoad();
    currentData = averageDataForColumns(rawData);
  }

  const barWidth = Math.max(Math.floor(canvas.width / (columnsCount * 1.2)), 4); // подгоняем ширину
  const gap = 2;
  const radius = 3;

  const totalWidth = columnsCount * (barWidth + gap);
  const startX = canvas.width - totalWidth; // справа налево

  for (let i = 0; i < columnsCount; i++) {
    const value = currentData[i];
    const barHeight = (value / 100) * canvas.height;
    const x = startX + i * (barWidth + gap);
    const y = canvas.height - barHeight;

    if (value > 90) ctx.fillStyle = '#ff3b3b';
    else if (value > 80) ctx.fillStyle = '#ffb13b';
    else ctx.fillStyle = '#50ff8b';

    ctx.beginPath();
    ctx.moveTo(x, y + barHeight);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.lineTo(x + barWidth - radius, y);
    ctx.quadraticCurveTo(x + barWidth, y, x + barWidth, y + radius);
    ctx.lineTo(x + barWidth, y + barHeight);
    ctx.closePath();
    ctx.fill();
  }

  ctx.fillStyle = '#b9b9b9';
  ctx.font = '10px Inter, sans-serif';
  ctx.fillText('100%', 2, 10);
  ctx.fillText('0%', 2, canvas.height - 2);
}

// --- Автообновление каждые 30 минут ---
async function refreshData() {
  const rawData = await fetchNetdataNetworkLoad();
  currentData = averageDataForColumns(rawData);
  drawChart();
}
setInterval(refreshData, 30 * 60 * 1000); // каждые 30 минут

// --- Tooltip ---
function showTooltip(e) {
  const rect = canvas.getBoundingClientRect();
  const clientX = e.touches ? e.touches[0].clientX : e.clientX;
  const x = clientX - rect.left;

  const barWidth = Math.max(Math.floor(canvas.width / (columnsCount * 1.2)), 4);
  const gap = 2;
  const idx = Math.floor((x - (canvas.width - (columnsCount * (barWidth + gap)))) / (barWidth + gap));
  if (idx < 0 || idx >= columnsCount) return;

  const value = currentData[idx];
  const pointX = rect.left + (canvas.width - (columnsCount * (barWidth + gap))) + idx * (barWidth + gap) + barWidth / 2;
  const pointY = rect.top + canvas.height - (currentData[idx] / 100) * canvas.height;

  const now = new Date();
  now.setMinutes(now.getMinutes() - (columnsCount - 1 - idx) * 30);
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const timeLabel = `${hours}:${minutes}`;

  tooltip.textContent = `${value}%\n${timeLabel}`;
  tooltip.style.display = 'block';
  tooltip.style.left = (pointX - tooltip.offsetWidth / 2) + 'px';
  tooltip.style.top = (pointY - 38) + 'px';
}
function hideTooltip() { tooltip.style.display = 'none'; }

canvas.addEventListener('mousemove', showTooltip);
canvas.addEventListener('mouseleave', hideTooltip);
canvas.addEventListener('touchmove', showTooltip);
canvas.addEventListener('touchend', hideTooltip);

// --- Инициализация ---
drawChart();
